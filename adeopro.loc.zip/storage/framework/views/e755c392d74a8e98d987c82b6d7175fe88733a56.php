<?php $__env->startSection('content'); ?>
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-science icon-gradient bg-happy-itmeo"></i>
                </div>
                <div>Мой кабинет
                </div>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="text-danger"><?php echo e($error); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if(Session::has('message')): ?>
        <?php echo e(Session::get('message')); ?>

    <?php endif; ?>
    <div class="col-md-12 col-lg-12 col-xl-12">
        <div class="card-shadow-primary card-border mb-3 card">
            <div class="dropdown-menu-header">
                <div class="dropdown-menu-header-inner bg-primary">
                    <div class="menu-header-image"
                         style="background-image: url('assets/images/dropdown-header/city2.jpg');"></div>
                    <div class="menu-header-content">
                        <div class="avatar-icon-wrapper avatar-icon-lg">
                            <div class="avatar-icon rounded btn-hover-shine">
                                <img src="user.svg" alt="Avatar 5">
                            </div>
                        </div>
                        <div>
                            <h5 class="menu-header-title"><?php echo e(auth()->user()->name); ?></h5>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div class="card-header">Настройки</div>
                <div class="card-body">
                    <form class="form-row" action="<?php echo e(route('user.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-3">
                            <div class="position-relative form-group">
                                <label for="exampleEmail"><small>Почта (логин)</small><span class="text-danger">*</span></label>
                                <input name="email" id="exampleEmail" type="email"
                                       class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e($user->email); ?>" autofocus disabled>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="position-relative form-group">
                                <label for="fio"><small>Ф.И.О (для обращения)</small><span class="text-danger">*</span></label>
                                <input name="name" id="fio" type="text"
                                       class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e($user->name); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="position-relative form-group">
                                <label for="type"><small>Вид</small><span class="text-danger">*</span></label>
                                <select name="type" id="type" class="custom-select" required>
                                    <option value="0" <?php if($user->type == '0'): ?> selected <?php endif; ?>>Выбрать</option>
                                    <option value="1" <?php if($user->type == '1'): ?> selected <?php endif; ?>>Частное лицо</option>
                                    <option value="2" <?php if($user->type == '2'): ?> selected <?php endif; ?>>ИП</option>
                                    <option value="3" <?php if($user->type == '3'): ?> selected <?php endif; ?>>ООО</option>
                                    <option value="4" <?php if($user->type == '4'): ?> selected <?php endif; ?>>ЗАО</option>
                                </select>
                                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="position-relative form-group">
                                <label for="org"><small>Наименование</small><span class="text-danger">*</span></label>
                                <input type="text" id="org" name="org" required
                                       class="form-control <?php $__errorArgs = ['org'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($user->org); ?>">
                                <?php $__errorArgs = ['org'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="position-relative form-group">
                                <label for="org_type"><small>Вид деятельности</small><span class="text-danger">*</span></label>
                                <select name="org_type" id="org_type"
                                        class="custom-select <?php $__errorArgs = ['org_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="0"  <?php if($user->org_type == '0'): ?> selected <?php endif; ?>>Выбрать</option>
                                    <option value="1"  <?php if($user->org_type == '1'): ?> selected <?php endif; ?>>Автосервис</option>
                                    <option value="2"  <?php if($user->org_type == '2'): ?> selected <?php endif; ?>>Магазин автозапчастей</option>
                                    <option value="3"  <?php if($user->org_type == '3'): ?> selected <?php endif; ?>>Стол приема заказов</option>
                                </select>
                                <?php $__errorArgs = ['org_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="position-relative form-group">
                                <label for="country"><small>Страна</small><span class="text-danger">*</span></label>
                                <select name="country" id="country"
                                        class="custom-select <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <?php $__currentLoopData = \App\Models\Country::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country->id); ?>"  <?php if($user->country == $country->id): ?> selected <?php endif; ?>><?php echo e($country->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="position-relative form-group">
                                <label for="city"><small>Город</small><span class="text-danger">*</span></label>
                                <input type="text" name="city" id="city"
                                       class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                                       value="<?php echo e($user->city); ?>">
                                <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                        </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="position-relative form-group">
                                <label for="zip"><small>Индекс</small></label>
                                <input type="text" name="zip" id="zip" class="form-control" value="<?php echo e($user->zip); ?>">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="position-relative form-group">
                                <label for="address"><small>Адрес</small> <span class="text-danger">*</span></label>
                                <input type="text" name="address" id="address" class="form-control" required
                                       value="<?php echo e($user->address); ?>">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="position-relative form-group">
                                <label for="phone"><small>Контактный телефон</small><span
                                        class="text-danger">*</span></label>
                                <input type="text" name="phone" id="phone" class="form-control input-mask-trigger"
                                       data-inputmask="'mask': '+9(999) 999-9999'" required value="<?php echo e($user->phone); ?>">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="position-relative form-group">
                                <label for="site"><small>WWW страница</small></label>
                                <input type="text" name="site" id="site" class="form-control" value="<?php echo e($user->site); ?>">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="position-relative form-group">
                                <label for="icq"><small>icq</small></label>
                                <input type="text" name="icq" id="icq" class="form-control" value="<?php echo e($user->icq); ?>">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="position-relative form-group">
                                <label for="Skype"><small>Skype</small></label>
                                <input type="text" name="skype" id="Skype" class="form-control"
                                       value="<?php echo e($user->skype); ?>">
                            </div>
                        </div>
                        <div class="col-md-12 text-center">
                            <button class="btn-wide btn-shadow btn-hover-shine btn btn-primary my-3" type="submit">
                                Сохранить
                            </button>
                        </div>

                    </form>
                    <form action="<?php echo e(route('password.update')); ?>" class="form-row card" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="card-header">Пароль</div>
                        <div class="card-body row">
                            <div class="col-md-6">
                                <div class="position-relative form-group">
                                    <label for="examplePassword"><small>Старый пароль</small><span
                                            class="text-danger">*</span></label>
                                    <input name="oldPassword" id="examplePassword" type="password"
                                           class="form-control <?php $__errorArgs = ['Oldpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="" required>
                                    <?php $__errorArgs = ['Oldpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="position-relative form-group">
                                    <label for="password_confirmation"><small>Новый пароль</small><span
                                            class="text-danger">*</span></label>
                                    <input name="newPassword" id="password_confirmation" type="password"
                                           class="form-control" autocomplete="new-password" required>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 text-center">
                            <button class="btn-wide btn-shadow btn-hover-shine btn btn-primary my-3" type="submit">
                                Обновить пароль
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-pure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\adeopro.loc\resources\views/cabinet/index.blade.php ENDPATH**/ ?>