<?php $__env->startSection('content'); ?>
    <div class="modal-dialog w-100 mx-auto">
        <div class="modal-content">
            <div class="modal-body">
                <h5 class="modal-title my-3">
                    Авторизация
                </h5>
                <form class="" action="<?php echo e(route('login')); ?>" method="POST" id="login">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="col-md-12">
                            <div class="position-relative form-group">
                                <input name="email" id="exampleEmail" placeholder="Логин" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="position-relative form-group">
                                <input name="password" id="examplePassword" placeholder="Пароль" type="password" class="form-control  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="position-relative form-check">
                        <input name="remember" id="exampleCheck" type="checkbox" class="form-check-input">
                        <label for="exampleCheck" class="form-check-label">Запомнить меня на этом компьютере</label>
                    </div>
                </form>
                <div class="divider"></div>
                <h6 class="mb-0">Нет аккаунта? <a href="<?php echo e(route('register')); ?>" class="text-primary">Зарегистрироваться</a></h6>
            </div>
            <div class="modal-footer clearfix">
                <div class="float-left">
                    <a href="<?php echo e(route('password.request')); ?>" class="btn-lg btn btn-link">Сброс пароля</a>
                </div>
                <div class="float-right">
                    <button class="btn btn-primary btn-lg" type="submit" onclick="event.preventDefault();document.getElementById('login').submit();">Войти</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-pure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\adeopro.loc\resources\views/auth/login.blade.php ENDPATH**/ ?>