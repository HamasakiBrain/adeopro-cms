<?php $__env->startSection('content'); ?>
    adminPanel;
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\adeopro.loc\resources\views/admin/index.blade.php ENDPATH**/ ?>