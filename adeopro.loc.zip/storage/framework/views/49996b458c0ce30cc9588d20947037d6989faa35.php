<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Добавление стран
                </div>
                <form class="card-body row" action="<?php echo e(route('admin.country.add')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="name" placeholder="Страна" required>
                    </div>
                    <div class="col-md-6 mt-sm-2 mt-lg-0">
                        <button class="btn btn-success" type="submit">Добавить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="row mt-2">
        <div class="col-md-5">
            <div class="card">
                <div class="card-header">Страны (<?php echo e(count($countries)); ?>)</div>
                <div class="card-body">
                    <ul class="todo-list-wrapper list-group list-group-flush">
                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <div class="todo-indicator bg-warning"></div>
                                <div class="widget-content p-0">
                                    <div class="widget-content-wrapper">
                                        <div class="widget-content-left ml-2">
                                            <div class="widget-heading">
                                                <?php echo e($country->name); ?>

                                            </div>
                                        </div>
                                        <div class="widget-content-right widget-content-actions">
                                            <a class="border-0 btn-transition btn btn-outline-danger" href="<?php echo e(route('admin.country.destroy', $country->id)); ?>">
                                                <i class="fa fa-trash-alt"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\adeopro.loc\resources\views/admin/country/create.blade.php ENDPATH**/ ?>