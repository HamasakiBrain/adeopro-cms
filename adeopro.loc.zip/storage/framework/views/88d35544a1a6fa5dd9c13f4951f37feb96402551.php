<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Новости')); ?></div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <table style="width: 100%;" id="testTable"
                               class="table table-hover table-striped table-bordered">
                            <thead>
                            <tr>
                                <th>Дата</th>
                                <th>ID заказа</th>
                                <th>Артикул</th>
                                <th>Наименование</th>
                                <th>Производитель</th>
                                <th>Примечание</th>
                                <th>Склад</th>
                                <th>Цена</th>
                                <th>Продажа</th>
                                <th>Сумма</th>
                            </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr> <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr> <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>
                                <tr>
                                    <td>19 июня 14:00</td>
                                    <td>3110000</td>
                                    <td>STYYY10010</td>
                                    <td>Тестовое название товара</td>
                                    <td>Test</td>
                                    <td>test</td>
                                    <td>Москва склад</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                    <td>1500 ₽</td>
                                </tr>


                            </tbody>
                            <tfoot>
                            <tr>
                                <th>Дата</th>
                                <th>ID заказа</th>
                                <th>Артикул</th>
                                <th>Наименование</th>
                                <th>Производитель</th>
                                <th>Примечание</th>
                                <th>Склад</th>
                                <th>Цена</th>
                                <th>Продажа</th>
                                <th>Сумма</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app-pure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\adeopro.loc\resources\views/home.blade.php ENDPATH**/ ?>