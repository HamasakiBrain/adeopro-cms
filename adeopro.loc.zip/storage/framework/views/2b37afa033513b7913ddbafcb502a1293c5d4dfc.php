<?php $__env->startSection('content'); ?>
    В разработке
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-pure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\adeopro.loc\resources\views/pages/payment.blade.php ENDPATH**/ ?>