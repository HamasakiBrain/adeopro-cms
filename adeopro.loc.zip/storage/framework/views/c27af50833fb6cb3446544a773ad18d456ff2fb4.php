<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-lg-6">
            <div class="card">
                <div class="card-header">
                    Добавление дилеров
                </div>
                <form class="card-body row" action="<?php echo e(route('admin.dillers.add')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group  col-md-6">
                        <input type="text" class="form-control" name="name" placeholder="ИП 'Дилер'" required>
                    </div>
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" name="corX" placeholder="Координаты X" required>
                    </div>
                    <div class="form-group  col-md-3">
                        <input type="text" class="form-control" name="corY" placeholder="Координаты Y" required>
                    </div>
                    <div class="form-group  col-md-4">
                        <input type="text" class="form-control" name="address" placeholder="Адрес" required>
                    </div>
                    <div class="form-group  col-md-4">
                        <input type="text" class="form-control" name="phone" placeholder="Телефон" required>
                    </div>
                    <div class="col-md-6 mt-2">
                        <button class="btn btn-success" type="submit">Добавить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="row mt-2">
        <div class="col-md-12 col-lg-6">
            <div class="card">
                <div class="card-header">Дилеры (<?php echo e(count($dillers)); ?>)</div>
                <div class="card-body">
                    <ul class="todo-list-wrapper list-group list-group-flush">
                        <?php $__currentLoopData = $dillers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <div class="todo-indicator bg-warning"></div>
                                <div class="widget-content p-0">
                                    <div class="widget-content-wrapper">
                                        <div class="widget-content-left ml-2">
                                            <div class="widget-heading">
                                                <?php echo e($diller->name); ?>

                                            </div>
                                            <?php echo e($diller->address); ?>, <i><?php echo e($diller->phone); ?></i>
                                        </div>
                                        <div class="widget-content-right widget-content-actions">
                                            <a class="border-0 btn-transition btn btn-outline-danger" href="<?php echo e(route('admin.country.destroy', $diller->id)); ?>">
                                                <i class="fa fa-trash-alt"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\adeopro.loc\resources\views/admin/dillers/create.blade.php ENDPATH**/ ?>