<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="main-card mb-3 card col-md-6">
            <div class="card-header">Новости (<?php echo e(count($posts)); ?>)</div>
            <ul class="todo-list-wrapper list-group list-group-flush">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <div class="todo-indicator bg-info"></div>
                        <div class="widget-content p-0">
                            <div class="widget-content-wrapper">
                                <div class="widget-content-left ml-2">
                                    <div class="widget-heading">
                                        <?php echo e($post->title); ?>

                                        <div class="badge badge-info ml-2"><?php echo e($post->type); ?></div>
                                    </div>

                                    <div class="widget-subheading"><i><?php echo e($post->description); ?></i></div>
                                </div>
                                <div class="widget-content-right widget-content-actions">
                                    <a href="<?php echo e(route('admin.posts.destroy', $post->id)); ?>" class="border-0 btn-transition btn btn-outline-danger">
                                        <i class="fa fa-trash-alt"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
               <div class="mt-3">
                   <?php echo e($posts->links()); ?>

               </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">Создание новостей</div>
                <form class="card-body" action="<?php echo e(route('admin.posts.add')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                     <div class="form-group">
                         <label for="title">Заголовок</label>
                         <input type="text" name="title" id="title" class="form-control" required>
                     </div>
                    <div class="form-group">
                        <label for="description">Описание</label>
                        <input type="text" name="description" id="description" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="type">Тип</label>
                        <select name="type" id="type" class="form-control">
                            <option value="0" selected>Наши</option>
                            <option value="1">Дилера</option>
                        </select>
                    </div>
                    <button class="btn btn-success w-100" type="submit">Добавить</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\adeopro.loc\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>