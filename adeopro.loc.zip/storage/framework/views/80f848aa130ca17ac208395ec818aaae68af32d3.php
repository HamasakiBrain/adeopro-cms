<?php $__env->startSection('content'); ?>
    <div class="main-card mb-3 card">
        <div class="card-header">Пользователи</div>
        <ul class="todo-list-wrapper list-group list-group-flush">
           <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <div class="todo-indicator bg-warning"></div>
                    <div class="widget-content p-0">
                        <div class="widget-content-wrapper">
                            <div class="widget-content-left ml-2">
                                <div class="widget-heading">
                                    <?php echo e($user->name); ?>

                                    <div class="badge badge-info ml-2"><?php echo e($user->org); ?></div>
                                    <div class="badge badge-success ml-2"><?php echo e($user->phone); ?></div>
                                    <?php if($user->isAdmin): ?>
                                        <div class="badge badge-danger ml-2">АДМИН</div>
                                    <?php endif; ?>
                                </div>
                                <div class="widget-subheading"><i><?php echo e($user->country); ?></i></div>
                            </div>
                            <div class="widget-content-right widget-content-actions">
                                <a href="<?php echo e(route('admin.users.destroy', $user->id)); ?>" class="border-0 btn-transition btn btn-outline-danger">
                                    <i class="fa fa-trash-alt"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </li>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\adeopro.loc\resources\views/admin/users/index.blade.php ENDPATH**/ ?>