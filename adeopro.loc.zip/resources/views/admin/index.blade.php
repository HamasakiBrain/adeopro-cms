@extends('admin.layouts.app')
@section('content')
    adminPanel;
@endsection
