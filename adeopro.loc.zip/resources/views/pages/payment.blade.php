@extends('layouts.app-pure')
@section('content')
    В разработке
@endsection
